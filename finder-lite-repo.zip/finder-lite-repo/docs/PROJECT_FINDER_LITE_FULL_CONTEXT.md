# PROJECT FINDER-LITE — Complete Implementation Context
**Last Updated:** July 2026 | **Status:** Hackathon POC Phase | **Author:** Murugan (embedded systems engineer, India)

---

## EXECUTIVE SUMMARY

**What is this?**
A multi-modal Search and Rescue (SAR) robot payload bay and triage-scanning system inspired by NASA JPL's FINDER system. NOT a true through-rubble radar (that requires low-frequency UWB, which is out of scope for a hackathon POC). Instead, this is a **close-range, line-of-sight surface/room-clearing triage scanner** that demonstrates FINDER's sensor-fusion logic: multiple independent modalities (radar + thermal + audio) voting to discriminate survivors from false positives.

**Why not "real" FINDER?**
- FINDER's penetrating power comes from UWB/low-frequency radar that diffracts through rubble (hundreds of MHz to low GHz).
- This build uses 24GHz FMCW radars (LD2450, LD2412), which are line-of-sight only.
- That's a physical/cost limitation, not a logic gap — the *decision-making* is genuinely FINDER-inspired.

**Hackathon Pitch:**
"This demonstrates FINDER's sensor-fusion and autonomous-triage logic operating on close-range radars as a POC. Scaling to true through-rubble penetration would require UWB hardware; the decision pipeline is identical."

---

## HARDWARE STACK

### Primary Controller
- **STM32F411VE** (100-pin LQFP, ARM Cortex-M4 @ 100MHz)
  - Local C processing via HAL drivers + DMA buffers
  - UART1: LD2450 spatial radar (115200 baud)
  - UART6: LD2412 breathing radar (115200 baud)
  - I2C1: GY-906 (Melexis MLX90614) infrared thermal sensor
  - I2S: INMP441 digital microphone with DMA into circular buffer
  - TIM2_CH1, TIM2_CH2: PWM servo control (pan/tilt mechanism)

### Wireless Network Bridge
- **ESP32** (Arduino IDE, bare-minimum UART-to-Wi-Fi UDP relay sketch)
  - Receives packed C struct from STM32 over USART @ 115200 baud
  - Forwards UDP packets to a host laptop running the Python visualization

### Mechanical
- **2-Axis Servo Pan-Tilt Mount** (creates 3D spherical scanning pattern)
  - Pan servo: 30°–150° azimuth (TIM2_CH1, PWM 1.0–2.0ms)
  - Tilt servo: 30°–150° elevation (TIM2_CH2, PWM 1.0–2.0ms)

### Drone Integration (S500 + DAKEFPV F722)
- **S500 Frame** (500mm diagonal, quad)
- **DAKEFPV F722 Flight Controller** running **INAV firmware** (not BetaFlight; flash constraints)
- **Motors:** 920KV RTosky 2212 (4x)
- **ESCs:** 4x SimonK (PWM/OneShot protocol — NOT DShot; must set explicitly in INAV config)
- **Battery:** 3S 5200mAh 45C (tight T/W margin; ~1.8:1 thrust-to-weight fully loaded)
- **GPS:** GEPRC M10 with IST8310 compass
- **Thrust-to-Weight Reality Check:** This is flyable but with minimal margin. Hover will draw close to peak efficiency. **Recommendation:** Primary demo is ground-mounted; drone carry is secondary/stretch if time permits.

### Sensor Payload Bay Layout
```
STM32F411VE (Master)
    ├─ LD2450 (24GHz 2D tracking radar) → spatial coordinate vectors
    ├─ LD2412 (24GHz 1D FMCW "stare" radar) → breathing rate via distance gates
    ├─ INMP441 (I2S microphone) → acoustic cues (500Hz–3000Hz band energy)
    ├─ GY-906 (I2C infrared thermal) → human-range thermal validation
    └─ [2x servo pan-tilt] → points sensors at targets
         └─ ESP32 (UDP relay) → laptop visualization
```

---

## SENSOR SPECIFICATIONS & RANGES

| Sensor | Type | Max Range | Key Capability | Notes |
|--------|------|-----------|-----------------|-------|
| LD2450 | 24GHz 2D FMCW | ~6–8m bulk motion | Multi-target tracking (x, y coords) | Spatial cueing; tracks moving + stationary |
| LD2412 | 24GHz 1D FMCW | ~3–5m breathing | Micro-motion extraction @ distance gate | Requires close dwell (0.7m typical) |
| INMP441 | I2S microphone | ~5m (omnidirectional) | Acoustic event detection | Band-energy in 500–3000Hz; global (non-localized) |
| GY-906 | I2C IR thermal | ~2m (narrow FOV) | Non-contact surface temp | Biological validation gate (human ~30–38°C) |

**Range Reality Check:** LD2412 breathing-lock is your precision bottleneck. Online reviews claiming "10m" are usually detecting *presence* (gross motion), not *breathing*. Empirically test your actual unit in your demo venue at 2m, 4m, 6m before the day.

---

## CORE SYSTEM LOGIC & MATHEMATICS

### 1. Data Transmission Protocol (STM32 → ESP32 → Laptop)

```c
typedef struct {
    uint8_t  start_marker;     // 0xAA
    uint8_t  pan_angle;        // Azimuth (30°–150°, mapped to 0–255)
    uint8_t  tilt_angle;       // Elevation (30°–150°)
    uint16_t target_distance;  // LD2412 distance (mm)
    uint16_t breathing_rate;   // LD2412 breathing (BPM)
    float    object_temp;      // GY-906 target temp (°C)
    int16_t  audio_peak;       // INMP441 raw peak amplitude
    uint8_t  end_marker;       // 0xBB
} __attribute__((packed)) PayloadFrame;
```

**Critical Note:** 0xAA/0xBB byte markers can collide with data (e.g., a float byte might equal 0xAA). **Real fix:** use COBS (Consistent Overhead Byte Stuffing) or fixed-length + checksum, not relying on marker bytes alone for frame sync.

### 2. Motion Classification (Velocity Estimation)

```python
def classify_motion(target):
    """
    Computes velocity over a rolling window (14 frames @ 0.15s/frame = ~2.1s).
    Returns "MOVING" if sustained velocity > 0.35 m/s, else "QUASI_STATIC".
    """
    if len(history) < 2:
        return "QUASI_STATIC"
    disp = norm(history[-1] - history[0])
    time_span = DT * (len(history) - 1)
    velocity = disp / time_span
    return "MOVING" if velocity > MOVING_THRESHOLD else "QUASI_STATIC"
```

**Why this matters:** Walking bystanders (0.5–1.5 m/s) are easily separated from pinned/trapped victims (micro-motion only, ~0cm per second). This is the first and strongest filter.

### 3. Fusion State Machine (Real Decision Logic)

The **actual FINDER-like autonomy** lives here. This is a state machine running on the STM32 (or ported to Python for simulation) that makes *unscripted* decisions:

```
STATE: SCANNING
  ├─ LD2450 reports up to 3 target clusters (x, y, velocity)
  ├─ Classify each as MOVING / QUASI_STATIC
  └─ If quasi-static candidate found within STARE_RANGE (5m):
      └─ Pan/tilt servos slew toward it
      └─ Transition → DIVERTING

STATE: DIVERTING
  ├─ Move toward candidate's position until within reach (~0.6m)
  └─ Transition → STARING

STATE: STARING (dwell for STARE_DWELL = 5.0 seconds)
  ├─ Poll LD2412 breathing-rate register at that distance gate
  ├─ Run INMP441 acoustic band-energy check (Goertzel or FFT)
  ├─ Accumulate confidence score:
  │   +40 if LD2412 breathing rate in [8, 30] BPM (human-plausible)
  │   +30 if LD2412 maintains stable lock (low variance)
  │   +20 if INMP441 detects acoustic burst
  │   +10 for temporal consistency (completing full dwell)
  └─ After dwell:
      ├─ If score >= CONFIRM_THRESHOLD (60): → CONFIRMED survivor
      ├─ Else: → REJECTED (false positive)
      └─ Return to SCANNING

STATE: COVERAGE (continuous scanning mode)
  ├─ If no candidates, autonomously compute next unvisited grid cell
  ├─ Move toward that cell (frontier/lawnmower search)
  └─ Repeat
```

**This is genuinely autonomous:** the system doesn't have a hardcoded path. It makes real decisions based on sensor data and the current goal (cover all space, confirm survivors).

### 4. Confidence Scoring Rationale

```python
def compute_confidence(target, breathing_rate, breathing_clean_lock, acoustic_hit):
    score = 0
    if breathing_clean_lock and 8 <= breathing_rate <= 30:
        score += 40  # strongest signal: human-plausible breathing
    if classify_motion(target) == "QUASI_STATIC":
        score += 30  # not moving = likely trapped, not bystander
    if acoustic_hit:
        score += 20  # tapping/shouting corroborates
    score += 10     # temporal consistency bonus
    return score
```

**Why these weights?** Breathing rate is the *rarest* signal to fake (debris won't breathe at 16 BPM). Acoustic hits are common in any environment. Velocity classification is strong but imperfect (someone standing still at a counter). The multi-modal approach rejects false positives that any single sensor would accept.

---

## CURRENT HARDWARE ISSUES & STATUS

### I2C Error Count (55 cycles in INAV)
- **Likely cause:** GEPRC M10 GPS module's IST8310 compass not properly initialized or wiring incomplete
- **Fix:** In INAV CLI, run `set mag_hardware = IST8310` (not AUTO), then `save`
- **Verify:** Run `status` in CLI, check `MAG=` field (should show IST8310 detected, not FAILING)
- **If still failing:** Check physical SCL/SDA wiring from GPS module to FC; confirm both UART and I2C lines are connected

### ESC Protocol (SimonK, not DShot)
- **Set explicitly in INAV CLI:** `set motor_pwm_protocol = PWM` (or `ONESHOT125` if supported by your SimonK version)
- **Verify:** Test throttle responsiveness on bench (props OFF) before flight test

### Thrust-to-Weight Margin
- **Reality:** ~1.8:1 T/W with full sensor payload on 3S battery
- **Implication:** Flyable but no margin for wind gusts or aggressive maneuvers
- **Recommendation:** Keep flight demo conservative (hover in place, low altitude) or skip full flight and demo as ground platform + simulated trajectory

### Radar Mutual Interference
- **LD2450 + LD2412 running simultaneous 24GHz** can cause cross-coupling
- **Mitigation:** Time-multiplex their active windows (e.g., LD2450 sweeps 0–100ms, LD2412 dwells 100–200ms) OR accept degradation as minor noise (OK for POC)

---

## SIMULATION & VISUALIZATION LAYER

### Why Python, Not Gazebo?
- Gazebo + ArduPilot SITL is *real* but requires days of environment setup (ROS, Gazebo Garden/Harmonic, plugin compilation, WSL GPU passthrough debugging)
- Python simulator with isometric rendering is a **guaranteed working demo** in hours, zero environment risk
- Same fusion state machine logic (portable to C/STM32 near-verbatim) runs in both sim and real hardware

### What the Python Sim Does

**File:** `sar_sim.py` (included)

**Rendering:**
- Isometric pseudo-3D projection (hand-rolled, no external 3D lib)
- Extruded rubble obstacles with shaded faces
- Standing target markers with drop shadows (human pins)
- Hovering drone with floor shadow + connector line
- Rotating radar sweep + range rings (2m, 4m, 6m)
- Real-time confidence meter filling as dwell progresses
- Pulsing red glow + flash banner on confirmed survivors

**Logic:**
- Real autonomous frontier-search coverage planner (lawnmower/nearest-unvisited-cell algorithm)
- Real SCANNING → DIVERTING → STARING → CONFIRMED/REJECTED state machine
- Synthetic sensor inputs (breathing rate, acoustic hits) mapped to realistic human vs. bystander profiles
- Live event log and HUD panel showing decision chain

**Run:**
```bash
python3 sar_sim.py
```
(Requires `matplotlib`, `numpy` — standard scientific-Python packages)

**Customize (top of file):**
```python
STARE_DWELL = 5.0              # seconds to dwell on candidate (lower = faster demo)
CONFIRM_THRESHOLD = 60         # confidence score needed to confirm
MOVING_THRESHOLD = 0.35        # m/s velocity threshold
SENSOR_RANGE = 6.0             # LD2450 detection range (m)
```

---

## NEXT STEPS BY PRIORITY

### Phase 1: Bench Validation (1–2 days)
1. **STM32 firmware:** Verify each peripheral (I2C thermal, I2S mic, UART radars, servo PWM)
   - Test LD2450 reporting target x/y/velocity
   - Test LD2412 breathing-rate lock at 0.7m, 2m, 4m distances
   - Test GY-906 temperature reading
   - Test INMP441 audio DMA buffer filling + FFT/band-energy compute
   - Test servo PWM pan/tilt movement

2. **ESP32 relay:** Verify UDP packets arriving on laptop with correct payload structure

3. **Python sim:** Run `sar_sim.py`, verify state machine logic visually (watch autonomous target prioritization)

4. **INAV/F722:** Fix I2C errors, verify compass + ESC protocol, test hover stability

### Phase 2: Integration Demo (1 day before hackathon)
1. **Real STM32 + sensor rig on desk** sending live UDP packets to laptop
2. **Python visualization receiving + displaying real sensor data** in real time
3. **Live demo script:**
   - Place 3 bystanders (stationary teammates) and 1 "victim" (teammate lying still, occasionally tapping)
   - Run `sar_sim.py` connected to real UDP stream
   - Watch system autonomously scan, divert to candidates, stare, and confirm the victim while rejecting bystanders
   - Point out: velocity classification, confidence score climbing in real time, final "CONFIRMED SURVIVOR" flash

### Phase 3: Drone Integration (Stretch / Post-Hackathon)
1. Mount sensor bay on S500 + F722 frame with vibration isolation (soft grommets)
2. Test hover stability with full payload (no heavy wind)
3. Wire STM32 UART to F722's spare UART for MAVLink telemetry if autonomy is desired
   - Otherwise, just carry payload and demo ground-station visualization while hovering

### Phase 4: Advanced Enhancements (Not for First Hackathon)
- [ ] Add line-of-sight occlusion logic (targets/obstacles block sensor rays)
- [ ] Integrate real MAVLink attitude (pitch/roll/yaw) to stabilize pan/tilt angles in flight
- [ ] Port fusion state machine to C on STM32, replace Python simulation with real embedded logic
- [ ] Add RCWL-0516 3.2GHz microwave radar tapped CDS analog output for lower-frequency confirmation layer
- [ ] Replace 24GHz radars with Walabot UWB for real through-wall penetration (true FINDER capability)

---

## TECHNICAL NOTES FOR IMPLEMENTATION

### Frame Markers (CRITICAL BUG FIX)
Current protocol uses 0xAA/0xBB start/end bytes, which can collide with payload data.
**Real fix:** use COBS (Consistent Overhead Byte Stuffing) or fixed-length + CRC checksum:
```c
// Option A: COBS (cleaner)
// Encode: cobs_encode(frame_ptr, frame_len, output_buffer)
// Decode: cobs_decode(input_buffer, output_frame)

// Option B: Fixed-length + CRC16 (simpler, smaller)
typedef struct {
    uint8_t  pan_angle;
    uint8_t  tilt_angle;
    uint16_t target_distance;
    uint16_t breathing_rate;
    float    object_temp;
    int16_t  audio_peak;
    uint16_t crc16;  // Compute over all above fields
} PayloadFrame;
// Send fixed 16 bytes + CRC every time, no markers
```

### LD2412 Breathing Detection (Real Implementation Notes)
- **Distance gate tuning:** LD2412 has configurable gate distance (0.25m–9.75m, 0.25m increments). Tune to your expected victim range.
- **Stability:** Breathing signal has very low SNR. Use 5+ consecutive stable reads before declaring a "lock."
- **Filtering:** A simple IIR low-pass (alpha ~0.3) on the reported BPM helps reject noise spikes.

### INMP441 Audio Processing
Simple Goertzel filter (compute single-frequency energy) is lighter than FFT:
```c
// Pseudocode: Goertzel at 1500 Hz (mid-band for tapping)
float goertzel_1500hz(int16_t *audio_buf, int len, int sample_rate) {
    float q0 = 0, q1 = 0, q2 = 0;
    float coeff = 2 * cos(2 * PI * 1500 / sample_rate);
    for (int i = 0; i < len; i++) {
        q0 = audio_buf[i] + coeff * q1 - q2;
        q2 = q1; q1 = q0;
    }
    float energy = q1*q1 + q2*q2 - coeff*q1*q2;
    return sqrt(energy);
}
// Repeat for 500 Hz, 1500 Hz, 3000 Hz; sum energies.
// Threshold on total energy to detect acoustic events.
```

### Servo Pan/Tilt Mapping
```c
// Convert LD2450 target (x, y) in meters to pan/tilt angles
float pan_angle_deg = atan2(target_y - drone_y, target_x - drone_x) * 180 / PI;
float tilt_angle_deg = 90 - atan2(0.5, distance_to_target) * 180 / PI;  // rough elevation estimate
// Clamp to servo range [30°, 150°]
pan_angle_deg = constrain(pan_angle_deg, 30, 150);
tilt_angle_deg = constrain(tilt_angle_deg, 30, 150);
// Convert to PWM pulse width (1.0–2.0 ms for typical servos)
pwm_pulse_ms = 1.5 + (pan_angle_deg - 90) / 90 * 0.5;
```

### Autonomous Coverage Path Planning
Simplest working algorithm: **nearest-unvisited grid cell**
```python
def next_unvisited_cell(drone_pos, grid):
    unvisited = grid.find_all_unvisited()
    if not unvisited:
        grid.reset_all()  # restart sweep
        return next_unvisited_cell(...)
    centers = [cell_center(c) for c in unvisited]
    nearest = min(centers, key=lambda c: distance(drone_pos, c))
    return nearest
```
This is genuinely *autonomous*: the drone picks its own next waypoint, not a hardcoded path.

---

## DEMO SCRIPT FOR HACKATHON JUDGES

### Setup (5 min before judges arrive)
1. Run Python sim: `python3 sar_sim.py`
2. Start STM32 firmware + ESP32 relay (or run headless sim if hardware not ready)
3. Teammates: position 3 "bystanders" (standing/walking) and 1 "victim" (lying still, occasional tapping)
4. Seat judges where they can see the screen

### Demo Narrative (3–5 min)
> "This is Project FINDER-Lite, a multi-modal SAR triage system. Unlike NASA's ground-penetrating radar, we're using 24GHz radars for close-range room clearing — think bomb-squad or firefighter sweep. The key innovation is sensor fusion: we don't trust any single modality.
>
> Watch the system autonomously scan the space. The cyan dots are people. When it finds someone standing still [pause, watch blue → yellow transition], it thinks 'candidate,' diverting to investigate. Once close, it stares for 5 seconds, checking breathing rate, thermal signature, acoustic cues. [Watch confidence meter fill.] If enough sensors agree, boom — [flash] — SURVIVOR CONFIRMED.
>
> Notice how it [watches bystander move] rejects that person immediately — they're walking, so probably not trapped. The real survivor [points to yellow → red] gets locked on because they're stationary *and* showing breathing *and* occasionally tapping.
>
> This entire decision loop — velocity classification, dwell sequencing, multi-sensor voting — is the FINDER logic. Scaling to true through-rubble range would swap out these 24GHz radars for UWB, but the autonomy stays identical."

### Q&A Talking Points
- **"How do you avoid false positives?"** → Multi-modal fusion. Rubble is stationary (✓ passes velocity check), but not breathing (✗ fails LD2412). Crying baby breathes (✓ LD2412) but may be trapped or just held by a parent; we require *also* quasi-static posture to confirm.
- **"Why not just use ground-penetrating radar?"** → Cost/size. FINDER-grade UWB hardware is research-grade; we're proving the logic on cheaper sensors first.
- **"Could this work on a drone?"** → [Honest answer:] Vibration breaks LD2412 breathing detection. We'd need vibration isolation or accept flying it as a remote sensor head (GCS doesn't interpret detections in flight, just logs raw data). Ground or pole-mounted is more reliable.
- **"What's the range?"** → Bulk motion (LD2450) works to ~6m; breathing lock (LD2412) realistically 2–5m depending on antenna & clutter. We tested empirically in our venue.

---

## FILES PROVIDED

- **`sar_sim.py`** — Complete Python simulator with isometric rendering. Run: `python3 sar_sim.py`
- **`PROJECT_FINDER_LITE_FULL_CONTEXT.md`** (this file) — Full implementation guide

---

## HARDWARE PINOUT REFERENCE (STM32F411VE)

| Peripheral | Pin | Function |
|-----------|-----|----------|
| UART1 TX/RX | PA9/PA10 | LD2450 spatial radar |
| UART6 TX/RX | PC6/PC7 | LD2412 breathing radar |
| I2C1 SDA/SCL | PB7/PB6 | GY-906 thermal sensor |
| I2S (PB12/PB13/PB15) | — | INMP441 microphone |
| TIM2_CH1 (PA0) | — | Pan servo PWM |
| TIM2_CH2 (PA1) | — | Tilt servo PWM |

(Adjust based on your actual STM32F411VE pinout document; above is a common reference)

---

## REFERENCES & FURTHER READING

- **NASA FINDER:** https://jpl.nasa.gov (search "FINDER" or "Finding Individuals for Disaster and Emergency Response")
- **LD2450 Datasheet:** HLK-LD2450 24GHz 2D Tracking Radar
- **LD2412 Datasheet:** HLK-LD2412 24GHz FMCW 1D Radar
- **INAV Firmware:** https://github.com/iNavFlight/inav
- **Goertzel Algorithm:** DSP for embedded frequency detection (no FFT overhead)
- **Isometric Projection Math:** Standard game-engine technique (cos/sin of 30° angles)

---

## KNOWN LIMITATIONS & HONEST ASSESSMENT

| Limitation | Impact | Mitigation |
|-----------|--------|-----------|
| 24GHz, not UWB | No penetration through rubble/walls | POC/teaching system; scale with UWB hardware later |
| Line-of-sight only | Obstacles block targets | Works for room-clearing; not applicable to collapsed structures |
| Breath detection range ~2–5m | Not stadium-scale | Acceptable for indoor SAR (typical room ~5–8m) |
| Vibration breaks LD2412 | Drone carry questionable | Ground/pole mount reliable; flight is stretch goal |
| Tight T/W ratio (1.8:1) | Low margin for gusts | Keep flight demo conservative; emphasize ground platform |
| Single INMP441 mic | No acoustic localization | Per-target audio would need mic array; not critical for POC |

---

## SUCCESS CRITERIA FOR HACKATHON

✅ **Must-Have:**
- State machine runs autonomously (no scripting detected by judges)
- Velocity classification correctly rejects walking bystanders
- Confidence meter fills live during dwell
- Final "CONFIRMED SURVIVOR" notification is clear and visual
- Event log shows decision chain (good talking point)

✅ **Should-Have:**
- Real sensor data flowing (STM32 → ESP32 → laptop) OR perfectly convincing sim
- At least 2–3 confirmed survivors in a live run (proof of concept working)
- Python visualization looks professional (tactical HUD, not debugging output)

✅ **Nice-to-Have:**
- Drone carrying payload (bonus points for integration)
- Multiple target prioritization (deciding which candidate to investigate first)
- Obstacle occlusion logic (targets behind rubble render correctly)

---

## FINAL NOTES FROM DEVELOPER

This project represents a real robotics problem (SAR triage) solved with pragmatic engineering (fusion logic that generalizes, simulation layer that sidesteps environment headaches, deliberate scope-limiting). The hardest part isn't the sensors — it's the *decision logic* that makes them useful together. That's what FINDER was actually about, and that's what this POC genuinely demonstrates.

Good luck at the hackathon. Keep the narrative clear, focus on the autonomy and multi-modal voting, and own the scope honestly. Judges respect engineering maturity far more than overclaiming capability.

— Murugan, July 2026

