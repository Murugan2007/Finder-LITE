# PROJECT FINDER-LITE
### Autonomous Multi-Modal Search & Rescue Triage System
*Hackathon Submission Document — July 2026*

---

## 1. PROBLEM STATEMENT

Every year, earthquakes, building collapses, and structural disasters trap thousands of survivors beneath rubble — and in Urban Search and Rescue (USAR) operations, the first "Golden Hour" after a collapse is the single greatest predictor of survival. Yet the tools available to first responders today remain painfully manual: trained canine units, acoustic listening devices, and visual inspection through voids — all slow, all limited by human fatigue, and all fundamentally *non-autonomous*.

NASA JPL's FINDER (Finding Individuals for Disaster and Emergency Response) proved over a decade ago that radar-based micro-Doppler sensing could detect a trapped survivor's heartbeat and breathing through **30 feet of rubble and 20 feet of solid concrete** — a genuine breakthrough. But FINDER-class hardware is expensive, specialized, and largely inaccessible to smaller response teams, student researchers, and resource-constrained rescue units, especially in developing regions where disaster response infrastructure is thinnest.

**The gap we identified:** there is no low-cost, open, autonomous platform that demonstrates *why* multi-sensor fusion works for survivor triage — one that a small team, a university lab, or a local disaster-response unit could build, understand, and iterate on without a NASA-scale budget.

**Project FINDER-Lite** closes that gap. We built an autonomous, multi-modal sensor-fusion platform that scans an environment, distinguishes trapped/incapacitated victims from bystanders in real time, and confirms survivors through independent corroborating evidence — all without a human operator in the loop. It's not a replacement for FINDER's penetrating radar; it's proof that the *decision intelligence* behind FINDER-class triage is replicable, teachable, and buildable by a small team in a matter of weeks.

---

## 2. METHODOLOGY

Our approach was structured around one core principle borrowed directly from FINDER's own design philosophy: **never trust a single sensor.** Rubble shifts. Fans hum. Bystanders stand still. Any single signal — motion, heat, or sound — produces false positives on its own. Genuine triage-grade confidence only emerges when multiple independent physical phenomena agree.

We approached the problem in four methodological phases:

### Phase 1 — Decompose the Detection Problem
We broke "is this a survivor?" into three independently falsifiable sub-questions:
1. **Is it stationary or trapped (not just walking through)?** → solved via radar-based velocity classification
2. **Is it alive (breathing)?** → solved via micro-Doppler breathing-rate extraction
3. **Is it responsive or distressed (tapping, calling, screaming)?** → solved via real-time acoustic monitoring

### Phase 2 — Design a Fusion Architecture, Not a Sensor Stack
Rather than simply logging sensor values, we engineered a **finite-state autonomous decision pipeline** (SCANNING → DIVERTING → HOLDING/STARING → CONFIRMED/REJECTED) that mirrors how an experienced USAR responder would actually triage a space: sweep broadly, notice something worth investigating, stop and focus, gather corroborating evidence, then commit to a decision.

### Phase 3 — Build for Validation Before Deployment
Recognizing that live-fire testing (real rubble, real flight risk) is impractical inside a hackathon timeline, we engineered a **parallel simulation layer** using the exact same fusion logic that runs on the embedded hardware. This let us validate, tune, and demo the decision-making algorithm with full confidence *before* ever depending on a live radar lock or a flying drone — a methodology directly inspired by how professional robotics teams de-risk hardware-dependent systems.

### Phase 4 — Design for Honest, Defensible Scope
We deliberately did not claim through-rubble detection. Instead, we scoped the system as a **close-range, line-of-sight triage scanner** — appropriate for room-clearing, tent searches, vehicle interiors, and voids with partial visibility — while architecting every piece of the pipeline (protocol, fusion logic, radar interface) to be forward-compatible with a future UWB radar swap for true through-rubble capability.

---

## 3. TECHNICAL APPROACH

### 3.1 System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     SENSOR PAYLOAD BAY                    │
│  HLK-LD2450 (2D spatial radar) ─────┐                     │
│  HLK-LD2412 (breathing radar)  ─────┤                     │
│  INMP441 (I2S acoustic array)  ─────┼──► STM32F411VE      │
│  GY-906 / MLX90614 (IR thermal)─────┤     (Cortex-M4,     │
│  2-axis servo pan-tilt mount   ─────┘      100 MHz)       │
└─────────────────────────────────────────────────────────┘
                          │  USART (packed struct)
                          ▼
                    ESP32 (Wi-Fi/UDP relay)
                          │
                          ▼
         Python Ground Control Station — live isometric
         tactical map, confidence telemetry, vitals-style
         waveform monitors, autonomous mission logging
```

### 3.2 Autonomous Fusion State Machine

The heart of the system is a four-state decision engine, engineered to be portable between our Python validation environment and the STM32 embedded target with minimal rewrite:

| State | Trigger | Behavior |
|---|---|---|
| **SCANNING / COVERAGE** | Default | Autonomously computes the nearest unexplored grid cell and moves to sweep it — a genuine frontier-style coverage planner, not a scripted path |
| **DIVERTING** | Quasi-static cluster detected | Pan-tilt mechanism autonomously slews and closes distance to the candidate |
| **HOLDING / STARING** | Within stare range | Platform **holds position for a full 10-second dwell window**, actively polling breathing-rate lock and acoustic band-energy |
| **CONFIRMED / REJECTED** | Dwell complete | Weighted confidence score is computed; survivors are confirmed, false positives are cleared, and the system resumes autonomous search |

### 3.3 Confidence Scoring Model

```
Score = 40 × [breathing rate in 8–30 BPM, clean radar lock]
      + 30 × [quasi-static motion classification]
      + 20 × [acoustic corroboration event detected]
      + 10 × [temporal consistency across full dwell]
──────────────────────────────────────────────
CONFIRMED if Score ≥ 60 / 100
```

This weighting deliberately privileges the signal that is *hardest to fake in the physical world* — a stable, human-plausible breathing-rate lock — while treating motion and acoustic evidence as supporting, not sufficient, criteria. This is the same layered-evidence philosophy that underlies FINDER's own clutter-rejection algorithms.

### 3.4 Real-Time Operator Interface

The ground station renders a live, isometric tactical dashboard including:
- **Room-accurate venue modeling** (square floor plan with a raised front stage, matching the actual deployment environment)
- **Live vitals-style waveform monitors** for breathing and acoustic signal, rendered exactly like a hospital monitor — spikes visibly present for a human target, flat/noisy for non-human clutter
- **Autonomous "hold and notify" behavior** — the platform physically stops, holds a 10-second dwell, and audibly notifies rescuers via buzzer the instant a candidate is under evaluation
- **Independent scream/distress detection channel** — a persistent, always-on acoustic monitor that can trigger an urgent alert and approximate location callout *regardless of where the platform is currently scanning*
- **Live location read-outs** for every active candidate, confirmed survivor, and distress event, giving rescuers actionable coordinates instantly

### 3.5 Communication Protocol

```c
typedef struct {
    uint8_t  start_marker;     // 0xAA
    uint8_t  pan_angle;        // 30°–150°
    uint8_t  tilt_angle;       // 30°–150°
    uint16_t target_distance;  // mm
    uint16_t breathing_rate;   // BPM
    float    object_temp;      // °C
    int16_t  audio_peak;       // raw amplitude
    uint8_t  end_marker;       // 0xBB
} __attribute__((packed)) PayloadFrame;
```
Transmitted STM32 → ESP32 → UDP → Ground Station at 10 Hz, enabling near-real-time telemetry with minimal latency.

### 3.6 Platform Integration

The full sensor bay is designed for dual deployment: as a **ground/pole-mounted triage station** (our primary, highest-reliability configuration) and as a **drone-carried payload** on an S500 quadcopter platform (INAV firmware, F722 flight controller) for aerial insertion into otherwise inaccessible spaces — engineered with vibration-isolation mounting to protect the breathing-radar signal chain from motor-induced noise.

---

## 4. FINAL REFLECTIONS AND FUTURE STEPS

### What We're Proud Of
Project FINDER-Lite proves something we think is genuinely underappreciated in disaster-tech circles: **the intelligence behind survivor triage is separable from the exotic hardware that made FINDER famous.** A team without access to research-grade UWB radar can still build, test, and validate the *entire decision-making pipeline* — the part that actually determines whether a system tells rescuers the truth — using sensors that cost a fraction of the price. That's a genuinely reusable contribution to the open disaster-robotics community, not just a hackathon demo.

We're also proud of our engineering discipline in **scope management**: rather than overclaiming through-rubble capability we couldn't deliver, we built a rigorously honest, line-of-sight triage system and architected every layer — protocol, fusion logic, even the simulation environment — to be a drop-in-compatible foundation for a future UWB upgrade. That's the difference between a demo that impresses for five minutes and a platform that a real team could keep building on.

### Known Limitations (Stated Candidly)
- Current 24 GHz radars are line-of-sight only; true rubble penetration requires a UWB radar front-end (Novelda, Walabot-class, or custom SDR)
- Breathing-lock reliability degrades meaningfully beyond ~5m and under vibration (a real constraint for drone-borne operation)
- Acoustic localization is currently approximate (single-microphone, room-wide detection) rather than precisely triangulated
- Thrust-to-weight margin on our current drone platform is workable but tight, favoring conservative, low-altitude flight profiles

### Future Roadmap
1. **UWB Radar Upgrade** — integrate a Novelda X4/X7 or Walabot-class front end to achieve genuine through-light-debris penetration, closing the gap toward true FINDER-class capability
2. **Embedded Fusion Porting** — migrate the validated Python fusion state machine to native C on the STM32 for fully self-contained, ground-station-independent operation
3. **MAVLink-Fused Flight Stabilization** — integrate real-time attitude data from the flight controller to stabilize pan-tilt targeting during aerial operation
4. **Multi-Microphone Acoustic Array** — add true phase-based sound localization to pinpoint distress calls, not just detect them
5. **Field Validation** — partner with a local USAR training facility or fire department to test against realistic rubble mock-ups and controlled scenarios
6. **Swarm Deployment** — extend the coverage-planning algorithm to coordinate multiple platforms across a larger disaster footprint simultaneously

---

## 5. EXPECTED DELIVERABLES

| # | Deliverable | Status |
|---|---|---|
| 1 | Fully autonomous multi-sensor fusion state machine (SCANNING → CONFIRMED) | ✅ Complete & validated in simulation |
| 2 | STM32F411VE embedded firmware for radar, thermal, acoustic, and servo control | ✅ Bench-validated |
| 3 | ESP32 Wi-Fi/UDP telemetry bridge | ✅ Functional |
| 4 | Live isometric ground-control dashboard with real-time vitals-style waveform monitoring | ✅ Complete |
| 5 | Autonomous "hold, notify, and locate" candidate-investigation behavior with buzzer alerts | ✅ Complete |
| 6 | Independent scream/distress detection channel with location callout | ✅ Complete |
| 7 | Drone-mounted payload integration (S500 + INAV/F722) | 🔶 Bench-integrated; flight validation ongoing |
| 8 | Full technical documentation & open build guide | ✅ Complete |
| 9 | Live demonstration with autonomous multi-target discrimination | ✅ Demo-ready |
| 10 | Roadmap for UWB upgrade path to true through-rubble capability | ✅ Scoped & documented |

---

## 6. RESEARCH PAPERS & REFERENCES

### FINDER & NASA JPL Foundational Work
- Cable, V. et al., *"Target & Propagation Models for the FINDER Radar,"* NASA Technical Reports Server.
  https://ntrs.nasa.gov/citations/20150007488
- NASA JPL, *"New Technology Can Detect Heartbeats in Rubble."*
  https://www.jpl.nasa.gov/news/new-technology-can-detect-heartbeats-in-rubble/
- NASA, *"NASA and Homeland Security Test Radar for Locating Disaster Victims."*
  https://www.nasa.gov/news-release/nasa-and-homeland-security-test-radar-for-locating-disaster-victims/
- NASA Spinoff, *"Radar Device Detects Heartbeats Trapped under Wreckage."*
  https://spinoff.nasa.gov/Spinoff2018/ps_1.html
- U.S. Department of Homeland Security S&T, *"FINDER Fact Sheet and Video."*
  https://www.dhs.gov/archive/science-and-technology/publication/st-finder-fact-sheet-and-video

### UWB & Radar-Based Vital Sign Detection (Future Upgrade Path)
- *"Ultra-Wideband Impulse Radar Through-Wall Detection of Vital Signs,"* Scientific Reports.
  https://www.nature.com/articles/s41598-018-31669-y
- *"Through-Wall Multi-Subject Localization and Vital Signs Monitoring Using UWB MIMO Imaging Radar,"* Remote Sensing (MDPI).
  https://www.mdpi.com/2072-4292/13/15/2905
- *"UWB Radar Self-Motion Cancelation for Through-Wall Vital Sign Detection,"* IEEE Xplore (relevant to drone-borne radar stability — directly informs our vibration-isolation roadmap).
  https://ieeexplore.ieee.org/document/10809193/
- *"A Multi-Target Localization and Vital Sign Detection Method Using Ultra-Wide Band Radar,"* PMC.
  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10346925/
- *"Accurate Heart Rate and Respiration Rate Detection Based on a Higher-Order Harmonics Peak Selection Method Using Radar Non-Contact Sensors,"* PMC.
  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8747437/

### Multi-Sensor Fusion for USAR Robotics (Direct Precedent for Our Approach)
- *"Presence-Gated VOC Sensing for Urban Search and Rescue Applications,"* Scientific Reports — notably uses a 24 GHz FMCW radar for human-presence gating exactly as we do.
  https://www.nature.com/articles/s41598-026-40990-w
- *"A Dataset for Victim Detection in Search-and-Rescue Operations Using Robot-Mounted UWB-Radar Sensors,"* Scientific Data.
  https://www.nature.com/articles/s41597-026-07314-z
- Gelfert, S., *"A Sensor Review for Human Detection with Robotic Systems in Regular and Smoky Environments,"* SAGE Journals.
  https://journals.sagepub.com/doi/full/10.1177/17298806231175238
- Gelfert, S. et al., *"Real Time Victim Detection in Smoky Environments with Mobile Robot and Multi-sensor Unit Using Deep Learning,"* Springer RiTA 2022.
  https://doi.org/10.1007/978-3-031-26889-2_32
- *"Autonomous Thermal Vision Robotic System for Victims Recognition in Search and Rescue Missions,"* PMC.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC8588524/
- *"Robust Multi-Sensor Fusion for Localization in Hazardous Environments Using Thermal, LiDAR, and GNSS Data,"* Sensors (MDPI).
  https://www.mdpi.com/1424-8220/25/7/2032

### Autonomous Coverage & Search Path Planning
- *"Optimal Frontier-Based Autonomous Exploration in Unconstructed Environment Using RGB-D Sensor,"* PMC — closely related to our coverage-planning algorithm.
  https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7697504/
- *"An Exact Coverage Path Planning Algorithm for UAV-Based Search and Rescue Operations,"* arXiv.
  https://arxiv.org/pdf/2405.11399
- *"Multi-Objective Drone Path Planning for Search and Rescue with Quality-of-Service Requirements,"* Autonomous Robots (Springer).
  https://link.springer.com/article/10.1007/s10514-020-09926-9
- Ewers, J-H. et al., *"Deep Reinforcement Learning for Time-Critical Wilderness Search and Rescue Using Drones,"* Frontiers in Robotics and AI.
  https://pmc.ncbi.nlm.nih.gov/articles/PMC11831046/
- *"An Innovative Coverage Path Planning Approach for UAVs to Boost Precision Agriculture and Rescue Operations,"* International Journal of Intelligent Systems (Wiley).
  https://onlinelibrary.wiley.com/doi/10.1155/int/4700518

---

*Project FINDER-Lite is presented as an educational and proof-of-concept platform. It is not certified for operational disaster response use. All range and capability figures for FINDER itself are drawn from published NASA JPL and DHS sources; figures for our own system reflect internal bench testing under controlled conditions.*
