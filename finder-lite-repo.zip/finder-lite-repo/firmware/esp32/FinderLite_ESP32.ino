/*
  ============================================================================
  PROJECT FINDER-LITE — ESP32 Dual-Radar Tracking Node
  ============================================================================
  Reads BOTH radars directly on the ESP32 (no STM32 needed for this stage),
  classifies each LD2450 target as MOVING or QUASI-STATIC, auto-aims a
  2-axis pan/tilt servo mount at the nearest static candidate, and serves a
  self-hosted live web dashboard (no laptop app required — just connect to
  the ESP32's Wi-Fi and open a browser).

  HARDWARE + PROTOCOL NOTES (verified against official Hi-Link datasheets):
  ----------------------------------------------------------------------------
  - HLK-LD2450  : UART @ 256000 baud, 8N1. NOT 115200 — this is a common
                   mistake. 30-byte frames: AA FF 03 00 [T1..T3, 8B each] 55 CC
                   Reports up to 3 targets with live X/Y (mm) AND speed
                   (cm/s) directly — we do NOT need to derive velocity from
                   position history, the radar gives it to us.
  - HLK-LD2412  : UART @ 115200 baud, 8N1. Variable-length frames:
                   F4 F3 F2 F1 [len:u16 LE] [type] AA [state] [mov_dist:u16]
                   [mov_energy] [still_dist:u16] [still_energy]
                   [detect_dist:u16] ... 55 00 F8 F7 F6 F5
                   Basic fields are always at the same fixed offsets whether
                   the module is in basic or engineering mode, so this parser
                   works for both.

  REQUIRED LIBRARY (install via Arduino Library Manager):
  ----------------------------------------------------------------------------
  - "ESP32Servo" by Kevin Harrington / madhephaestus

  WIRING:
  ----------------------------------------------------------------------------
  LD2450  TX -> ESP32 GPIO16 (RX1)      LD2450 RX -> ESP32 GPIO17 (TX1)
  LD2412  TX -> ESP32 GPIO26 (RX2)      LD2412 RX -> ESP32 GPIO27 (TX2)
  Pan servo signal -> GPIO18            Tilt servo signal -> GPIO19
  Both radars: 5V + GND. Servos: separate 5V supply recommended (do NOT
  power servos off the ESP32 3V3 rail — brownouts will corrupt UART reads).

  CAUTION: if your board is a WROVER variant (has onboard PSRAM), GPIO16/17
  are used internally for PSRAM and are NOT available for UART. Check your
  specific module — if it's WROVER, move LD2450 to two other free GPIOs
  (e.g. 4 and 5) and update LD2450_RX_PIN / LD2450_TX_PIN below. Plain
  WROOM-32 boards (no PSRAM) are fine with 16/17 as wired above.

  USAGE:
  ----------------------------------------------------------------------------
  On boot, the ESP32 starts a Wi-Fi Access Point:
      SSID: FINDER-LITE      PASSWORD: findertest123   (change below)
  Connect a phone/laptop to that network, then browse to:
      http://192.168.4.1/
  You'll see a live top-down radar plot (blue = moving, amber = static),
  the LD2412 presence/energy readout, and current pan/tilt angles.

  NOTE: This sketch has been written and verified against the official
  Hi-Link protocol documents but has NOT been compiled/flashed in this
  environment (no ESP32 toolchain available here). Please compile-check in
  Arduino IDE before your demo and verify against your specific module's
  firmware revision, since Hi-Link has shipped minor protocol variations
  across production batches.
  ============================================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

// ---------------------------------------------------------------------------
// CONFIG — adjust to your wiring / preferences
// ---------------------------------------------------------------------------
#define LD2450_RX_PIN   16
#define LD2450_TX_PIN   17
#define LD2450_BAUD     256000

#define LD2412_RX_PIN   26
#define LD2412_TX_PIN   27
#define LD2412_BAUD     115200

#define PAN_SERVO_PIN   18
#define TILT_SERVO_PIN  19
#define PAN_MIN_DEG     30
#define PAN_MAX_DEG     150
#define TILT_CENTER_DEG 90

#define MOVING_THRESHOLD_CMS   10     // speed above this = "moving"
#define HYSTERESIS_FRAMES      3      // consecutive frames needed to flip state
#define SWEEP_STEP_DEG         2
#define SWEEP_INTERVAL_MS      60
#define TRACK_HOLD_MS          10000  // matches the 10s "hold on candidate" behavior

const char* AP_SSID = "FINDER-LITE";
const char* AP_PASS = "findertest123";   // >= 8 chars required by WiFi AP

// ---------------------------------------------------------------------------
// GLOBAL STATE
// ---------------------------------------------------------------------------
HardwareSerial LD2450_SERIAL(1);
HardwareSerial LD2412_SERIAL(2);
WebServer server(80);
Servo panServo, tiltServo;

struct RadarTarget {
  bool     present      = false;
  int16_t  x_mm         = 0;
  int16_t  y_mm         = 0;
  int16_t  speed_cms    = 0;
  uint16_t resolution   = 0;
  bool     moving       = false;   // debounced classification
  uint8_t  moveVotes    = 0;       // hysteresis counters
  uint8_t  staticVotes  = 0;
  uint32_t lastUpdateMs = 0;
};
RadarTarget targets[3];

struct LD2412Status {
  uint8_t  targetState      = 0;   // 0=none 1=moving 2=still 3=both
  uint16_t movingDistanceCm = 0;
  uint8_t  movingEnergy     = 0;
  uint16_t stillDistanceCm  = 0;
  uint8_t  stillEnergy      = 0;
  uint16_t detectDistanceCm = 0;
  uint32_t lastUpdateMs     = 0;
};
LD2412Status ld2412;

// parser scratch buffers
uint8_t ld2450Buf[64];
int     ld2450Len = 0;
uint8_t ld2412BufArr[128];
int     ld2412Len = 0;

// servo / tracking state
float   panAngle    = 90.0;  // start centered
float   tiltAngle   = TILT_CENTER_DEG;
int     sweepDir    = 1;
uint32_t lastSweepMs = 0;
int     trackedTargetIdx = -1;
uint32_t trackStartMs    = 0;
enum TrackState { SWEEPING, DIVERTING, HOLDING };
TrackState trackState = SWEEPING;

// ---------------------------------------------------------------------------
// LD2450 PARSER
// HLK-LD2450 official protocol: sign+magnitude encoding, NOT two's complement.
// If the MSB of the high byte is SET -> value is POSITIVE.
// If the MSB of the high byte is CLEAR -> value is NEGATIVE.
// (Verified against the Hi-Link worked example in the official datasheet.)
// ---------------------------------------------------------------------------
int16_t decodeLD2450Signed(uint8_t lo, uint8_t hi) {
  uint16_t magnitude = (((uint16_t)hi << 8) | lo) & 0x7FFF;
  return (hi & 0x80) ? (int16_t)magnitude : -(int16_t)magnitude;
}

void classifyTarget(RadarTarget &t) {
  if (!t.present) { t.moving = false; t.moveVotes = 0; t.staticVotes = 0; return; }
  if (abs(t.speed_cms) > MOVING_THRESHOLD_CMS) {
    t.moveVotes++;
    t.staticVotes = 0;
    if (t.moveVotes >= HYSTERESIS_FRAMES) t.moving = true;
  } else {
    t.staticVotes++;
    t.moveVotes = 0;
    if (t.staticVotes >= HYSTERESIS_FRAMES) t.moving = false;
  }
}

void parseLD2450Frame(uint8_t *f) {
  for (int i = 0; i < 3; i++) {
    int o = 4 + i * 8;
    int16_t x   = decodeLD2450Signed(f[o + 0], f[o + 1]);
    int16_t y   = decodeLD2450Signed(f[o + 2], f[o + 3]);
    int16_t spd = decodeLD2450Signed(f[o + 4], f[o + 5]);
    uint16_t res = f[o + 6] | ((uint16_t)f[o + 7] << 8);

    RadarTarget &t = targets[i];
    t.present = (x != 0 || y != 0 || spd != 0);
    t.x_mm = x; t.y_mm = y; t.speed_cms = spd; t.resolution = res;
    t.lastUpdateMs = millis();
    classifyTarget(t);
  }
}

void pollLD2450() {
  while (LD2450_SERIAL.available()) {
    if (ld2450Len < (int)sizeof(ld2450Buf)) {
      ld2450Buf[ld2450Len++] = LD2450_SERIAL.read();
    } else {
      memmove(ld2450Buf, ld2450Buf + 1, sizeof(ld2450Buf) - 1);
      ld2450Buf[sizeof(ld2450Buf) - 1] = LD2450_SERIAL.read();
    }

    // search for header AA FF 03 00
    int hdr = -1;
    for (int i = 0; i <= ld2450Len - 4; i++) {
      if (ld2450Buf[i] == 0xAA && ld2450Buf[i+1] == 0xFF &&
          ld2450Buf[i+2] == 0x03 && ld2450Buf[i+3] == 0x00) { hdr = i; break; }
    }
    if (hdr < 0) {
      if (ld2450Len > 40) ld2450Len = 0;  // no header found in a while, reset
      continue;
    }
    if (hdr > 0) {
      memmove(ld2450Buf, ld2450Buf + hdr, ld2450Len - hdr);
      ld2450Len -= hdr;
    }
    if (ld2450Len < 30) continue;  // wait for full 30-byte frame

    if (ld2450Buf[28] == 0x55 && ld2450Buf[29] == 0xCC) {
      parseLD2450Frame(ld2450Buf);
    }
    memmove(ld2450Buf, ld2450Buf + 30, ld2450Len - 30);
    ld2450Len -= 30;
  }
}

// ---------------------------------------------------------------------------
// LD2412 PARSER
// Frame: F4 F3 F2 F1 [len u16 LE] [type] AA [state] [movD u16][movE]
//        [stillD u16][stillE][detectD u16] ... 55 00 F8 F7 F6 F5
// Basic fields sit at the same fixed offsets in both basic and engineering
// mode, so we only need to read the first 9 data bytes regardless of mode.
// ---------------------------------------------------------------------------
void parseLD2412Frame(uint8_t *f, int total) {
  if (total < 17) return;  // sanity check, malformed/short frame
  ld2412.targetState      = f[8];
  ld2412.movingDistanceCm = f[9]  | ((uint16_t)f[10] << 8);
  ld2412.movingEnergy     = f[11];
  ld2412.stillDistanceCm  = f[12] | ((uint16_t)f[13] << 8);
  ld2412.stillEnergy      = f[14];
  ld2412.detectDistanceCm = f[15] | ((uint16_t)f[16] << 8);
  ld2412.lastUpdateMs     = millis();
}

void pollLD2412() {
  while (LD2412_SERIAL.available()) {
    if (ld2412Len < (int)sizeof(ld2412BufArr)) {
      ld2412BufArr[ld2412Len++] = LD2412_SERIAL.read();
    } else {
      memmove(ld2412BufArr, ld2412BufArr + 1, sizeof(ld2412BufArr) - 1);
      ld2412BufArr[sizeof(ld2412BufArr) - 1] = LD2412_SERIAL.read();
    }

    int hdr = -1;
    for (int i = 0; i <= ld2412Len - 6; i++) {
      if (ld2412BufArr[i] == 0xF4 && ld2412BufArr[i+1] == 0xF3 &&
          ld2412BufArr[i+2] == 0xF2 && ld2412BufArr[i+3] == 0xF1) { hdr = i; break; }
    }
    if (hdr < 0) {
      if (ld2412Len > 100) ld2412Len = 0;
      continue;
    }
    if (hdr > 0) {
      memmove(ld2412BufArr, ld2412BufArr + hdr, ld2412Len - hdr);
      ld2412Len -= hdr;
    }
    if (ld2412Len < 8) continue;  // need header+len+type+datahead at least

    uint16_t dataLen = ld2412BufArr[4] | ((uint16_t)ld2412BufArr[5] << 8);
    int total = 6 + dataLen + 4;
    if (total <= 0 || total > (int)sizeof(ld2412BufArr)) {
      ld2412Len = 0;   // corrupt length field, resync
      continue;
    }
    if (ld2412Len < total) continue;  // wait for full frame

    if (ld2412BufArr[total-4] == 0xF8 && ld2412BufArr[total-3] == 0xF7 &&
        ld2412BufArr[total-2] == 0xF6 && ld2412BufArr[total-1] == 0xF5) {
      parseLD2412Frame(ld2412BufArr, total);
    }
    memmove(ld2412BufArr, ld2412BufArr + total, ld2412Len - total);
    ld2412Len -= total;
  }
}

// ---------------------------------------------------------------------------
// PAN/TILT TRACKING LOGIC
// SWEEPING  -> no static candidate: oscillate pan servo across its range
// DIVERTING -> a static candidate found: slew toward it
// HOLDING   -> aimed at candidate: hold for TRACK_HOLD_MS, then resume sweep
// ---------------------------------------------------------------------------
int findStaticCandidate() {
  for (int i = 0; i < 3; i++) {
    if (targets[i].present && !targets[i].moving) return i;
  }
  return -1;
}

float targetToPanAngle(const RadarTarget &t) {
  // x = lateral offset (mm), y = forward distance (mm)
  float angleRad = atan2((float)t.x_mm, (float)max((int16_t)1, t.y_mm));
  float deg = 90.0 + angleRad * 180.0 / PI;
  if (deg < PAN_MIN_DEG) deg = PAN_MIN_DEG;
  if (deg > PAN_MAX_DEG) deg = PAN_MAX_DEG;
  return deg;
}

void updateTracking() {
  uint32_t now = millis();

  if (trackState == SWEEPING) {
    int cand = findStaticCandidate();
    if (cand >= 0) {
      trackedTargetIdx = cand;
      trackState = DIVERTING;
    } else {
      if (now - lastSweepMs >= SWEEP_INTERVAL_MS) {
        lastSweepMs = now;
        panAngle += sweepDir * SWEEP_STEP_DEG;
        if (panAngle >= PAN_MAX_DEG) { panAngle = PAN_MAX_DEG; sweepDir = -1; }
        if (panAngle <= PAN_MIN_DEG) { panAngle = PAN_MIN_DEG; sweepDir = 1; }
      }
    }
  } else if (trackState == DIVERTING) {
    if (trackedTargetIdx < 0 || !targets[trackedTargetIdx].present ||
        targets[trackedTargetIdx].moving) {
      trackState = SWEEPING;   // lost the candidate, resume sweep
      trackedTargetIdx = -1;
    } else {
      float goal = targetToPanAngle(targets[trackedTargetIdx]);
      panAngle += constrain(goal - panAngle, -4.0, 4.0);  // smooth slew
      if (fabs(goal - panAngle) < 1.5) {
        trackState = HOLDING;
        trackStartMs = now;
      }
    }
  } else if (trackState == HOLDING) {
    if (trackedTargetIdx < 0 || !targets[trackedTargetIdx].present ||
        targets[trackedTargetIdx].moving) {
      trackState = SWEEPING;
      trackedTargetIdx = -1;
    } else if (now - trackStartMs >= TRACK_HOLD_MS) {
      trackState = SWEEPING;   // done holding, resume search
      trackedTargetIdx = -1;
    }
    // while holding, panAngle stays fixed on the candidate
  }

  panServo.write((int)panAngle);
  tiltServo.write((int)tiltAngle);
}

// ---------------------------------------------------------------------------
// WEB DASHBOARD
// ---------------------------------------------------------------------------
const char PAGE_HTML[] = R"HTML(
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FINDER-Lite Radar</title>
<style>
  body{background:#050b14;color:#7dd3fc;font-family:monospace;margin:0;padding:12px}
  h1{color:#22d3ee;font-size:16px;margin:4px 0 12px}
  #wrap{display:flex;gap:16px;flex-wrap:wrap}
  canvas{background:#0d1c2b;border:1px solid #1c3a52;border-radius:6px}
  .panel{background:#0a1522;border:1px solid #1c3a52;border-radius:6px;padding:10px;min-width:220px;font-size:13px}
  .row{margin:4px 0}
  .moving{color:#38bdf8}.static{color:#fbbf24}.dim{color:#3b5568}
  .badge{display:inline-block;padding:2px 6px;border-radius:4px;font-weight:bold}
</style></head><body>
<h1>PROJECT FINDER-LITE — LIVE RADAR FEED</h1>
<div id="wrap">
  <canvas id="c" width="360" height="360"></canvas>
  <div class="panel">
    <div class="row">STATE: <span id="state">-</span></div>
    <div class="row">PAN: <span id="pan">-</span>&deg;  TILT: <span id="tilt">-</span>&deg;</div>
    <hr style="border-color:#1c3a52">
    <div class="row"><b>LD2450 Targets</b></div>
    <div id="targets"></div>
    <hr style="border-color:#1c3a52">
    <div class="row"><b>LD2412 Presence</b></div>
    <div class="row">State: <span id="ld412state">-</span></div>
    <div class="row">Still: <span id="stillD">-</span>cm @ <span id="stillE">-</span>%</div>
    <div class="row">Moving: <span id="movD">-</span>cm @ <span id="movE">-</span>%</div>
  </div>
</div>
<script>
const c = document.getElementById('c'), ctx = c.getContext('2d');
const scale = 0.12; // px per mm
function draw(d){
  ctx.clearRect(0,0,360,360);
  ctx.strokeStyle="#16283a";
  for(let i=0;i<360;i+=30){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,360);ctx.stroke();
                            ctx.beginPath();ctx.moveTo(0,i);ctx.lineTo(360,i);ctx.stroke();}
  ctx.fillStyle="#22d3ee";ctx.beginPath();ctx.arc(180,350,5,0,7);ctx.fill(); // sensor origin
  let html="";
  d.targets.forEach((t,i)=>{
    if(!t.present) return;
    let px = 180 + t.x*scale, py = 350 - t.y*scale;
    ctx.fillStyle = t.moving ? "#38bdf8" : "#fbbf24";
    ctx.beginPath();ctx.arc(px,py,7,0,7);ctx.fill();
    ctx.fillText("T"+i, px+8, py);
    html += `<div class="row">T${i}: <span class="${t.moving?'moving':'static'}">`+
            `${t.moving?'MOVING':'STATIC'}</span> x=${t.x}mm y=${t.y}mm spd=${t.spd}cm/s</div>`;
  });
  document.getElementById('targets').innerHTML = html || '<span class="dim">no targets</span>';
  document.getElementById('state').innerText = d.state;
  document.getElementById('pan').innerText = d.pan.toFixed(1);
  document.getElementById('tilt').innerText = d.tilt.toFixed(1);
  document.getElementById('ld412state').innerText = ["none","moving","still","moving+still"][d.ld412.state] || d.ld412.state;
  document.getElementById('stillD').innerText = d.ld412.stillD;
  document.getElementById('stillE').innerText = d.ld412.stillE;
  document.getElementById('movD').innerText = d.ld412.movD;
  document.getElementById('movE').innerText = d.ld412.movE;
}
async function poll(){
  try{ const r = await fetch('/data'); const d = await r.json(); draw(d); }
  catch(e){ /* ignore transient errors */ }
  setTimeout(poll, 200);
}
poll();
</script></body></html>
)HTML";

void handleRoot() {
  server.send(200, "text/html", PAGE_HTML);
}

void handleData() {
  char buf[640];
  const char* stateStr = trackState == SWEEPING ? "SWEEPING" :
                          trackState == DIVERTING ? "DIVERTING" : "HOLDING";
  snprintf(buf, sizeof(buf),
    "{\"state\":\"%s\",\"pan\":%.1f,\"tilt\":%.1f,"
    "\"targets\":["
      "{\"present\":%s,\"x\":%d,\"y\":%d,\"spd\":%d,\"moving\":%s},"
      "{\"present\":%s,\"x\":%d,\"y\":%d,\"spd\":%d,\"moving\":%s},"
      "{\"present\":%s,\"x\":%d,\"y\":%d,\"spd\":%d,\"moving\":%s}"
    "],"
    "\"ld412\":{\"state\":%u,\"stillD\":%u,\"stillE\":%u,\"movD\":%u,\"movE\":%u}}",
    stateStr, panAngle, tiltAngle,
    targets[0].present?"true":"false", targets[0].x_mm, targets[0].y_mm, targets[0].speed_cms, targets[0].moving?"true":"false",
    targets[1].present?"true":"false", targets[1].x_mm, targets[1].y_mm, targets[1].speed_cms, targets[1].moving?"true":"false",
    targets[2].present?"true":"false", targets[2].x_mm, targets[2].y_mm, targets[2].speed_cms, targets[2].moving?"true":"false",
    ld2412.targetState, ld2412.stillDistanceCm, ld2412.stillEnergy,
    ld2412.movingDistanceCm, ld2412.movingEnergy
  );
  server.send(200, "application/json", buf);
}

// ---------------------------------------------------------------------------
// SETUP / LOOP
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\nProject FINDER-Lite — ESP32 dual-radar node booting...");

  LD2450_SERIAL.begin(LD2450_BAUD, SERIAL_8N1, LD2450_RX_PIN, LD2450_TX_PIN);
  LD2412_SERIAL.begin(LD2412_BAUD, SERIAL_8N1, LD2412_RX_PIN, LD2412_TX_PIN);

  panServo.setPeriodHertz(50);
  tiltServo.setPeriodHertz(50);
  panServo.attach(PAN_SERVO_PIN, 500, 2400);
  tiltServo.attach(TILT_SERVO_PIN, 500, 2400);
  panServo.write((int)panAngle);
  tiltServo.write((int)tiltAngle);

  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("AP started. Connect to Wi-Fi \"");
  Serial.print(AP_SSID);
  Serial.println("\" then browse to http://192.168.4.1/");

  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.begin();
  Serial.println("Web server started.");
}

void loop() {
  pollLD2450();
  pollLD2412();
  updateTracking();
  server.handleClient();
}
