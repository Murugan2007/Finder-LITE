# PROJECT FINDER-LITE — Quick Reference & Checklist

## TL;DR PROJECT PITCH
**Multi-modal SAR triage system using 24GHz radars + thermal + audio to autonomously detect and confirm survivors.** Fusion logic mirrors NASA FINDER; hardware is close-range POC (not through-rubble penetration). Autonomous state machine + Python isometric visualization.

---

## FASTEST PATH TO WORKING DEMO (Next 48 Hours)

### 1. Run Python Simulator (10 minutes)
```bash
python3 sar_sim.py
```
- See autonomous robot scanning, finding candidates, confirming survivors
- **This is 80% of what judges will care about** (the logic, not the flight)

### 2. Fix INAV I2C Issues (15 minutes)
```bash
# In INAV CLI:
set mag_hardware = IST8310
save
status  # verify MAG=IST8310 detected
```

### 3. Benchmark Your LD2412 Real Range (30 minutes)
- Place target at 2m, 4m, 6m from sensor
- Check if breathing-rate lock stays stable
- **Note actual reliable distance for your setup** (not online review claims)

### 4. Wire STM32 Peripherals (2–4 hours, depends on prior work)
- **Test each sensor independently first** (I2C thermal, UART radars, I2S mic)
- Don't wire everything at once
- Use oscilloscope or logic analyzer to verify UART / I2C bus activity

### 5. Bridge ESP32 Relay to Laptop (1 hour)
- Verify UDP packets arriving with correct PayloadFrame structure
- Plug STM32 output into Python visualization

### 6. Live Demo Run with Real Sensor Data (30 minutes)
- STM32 on desk sending live data
- Python sim receiving real UART stream
- Teammates positioned as bystanders + victim
- **Record this; use video if hardware fails on demo day**

---

## HARDWARE CHECKLIST

### STM32F411VE Firmware
- [ ] UART1 @ 115200 receiving LD2450 frames
- [ ] UART6 @ 115200 receiving LD2412 frames
- [ ] I2C1 reading GY-906 temperature
- [ ] I2S DMA circular buffer filling with INMP441 audio
- [ ] TIM2_CH1/CH2 PWM servo control (test: servos move 30°–150° range)
- [ ] Main loop packing PayloadFrame and sending to ESP32 every 100ms

### ESP32 Relay Sketch
- [ ] Reads UART from STM32 @ 115200
- [ ] Parses PayloadFrame (or just forwards raw bytes)
- [ ] Sends UDP to laptop IP:port

### INAV / F722 / S500
- [ ] `set motor_pwm_protocol = PWM` (not DShot, SimonK ESCs need PWM)
- [ ] `set mag_hardware = IST8310` (GEPRC M10 compass)
- [ ] Verified GPS lock (check telemetry for sat count)
- [ ] ESC calibration done, motors spin on throttle test (props OFF)
- [ ] Battery voltage sensor calibrated
- [ ] Hover test (props on, tethered or low altitude) — watch for drifting / instability

### Drone Payload Integration (if attempting)
- [ ] STM32 + ESP32 mounted on frame with vibration isolation (soft grommets/rubber pads)
- [ ] Power budget checked: BEC can supply STM32 + ESP32 + sensor current draw (estimated 500mA–1A)
- [ ] Weight budget: sensor bay ~150–300g; verify S500 + 3S battery can still hover with margin
- [ ] **Honest call:** If T/W feels tight or vibration isolation uncertain, stick to ground demo

---

## PYTHON SIMULATION TUNING

**File:** `sar_sim.py` (top of file)

```python
STARE_DWELL = 5.0           # seconds to confirm each candidate
                             # → Lower (2–3s) for faster demo pacing

CONFIRM_THRESHOLD = 60       # confidence score to declare survivor
                             # → Lower (50) = more lenient; higher (70) = stricter

MOVING_THRESHOLD = 0.35      # m/s velocity cutoff for "moving" vs "quasi-static"
                             # → Higher (0.5) = stricter; lower (0.2) = more lenient

SENSOR_RANGE = 6.0           # LD2450 detection range (m)
STARE_RANGE = 5.0            # must be this close to attempt stare
```

**Pro tip:** If demo is slow, lower `STARE_DWELL` to 2.0s and `CONFIRM_THRESHOLD` to 50. Judges see faster decision-making, demo finishes in 2–3 minutes instead of 10.

---

## COMMON ISSUES & FIXES

### Issue: "I2C error count 55 in INAV"
**Root cause:** GEPRC M10 compass (IST8310) not properly initialized.
**Fix:**
```bash
set mag_hardware = IST8310
save
# Reboot FC
status  # verify MAG=IST8310 detected
```
If still failing: check physical SCL/SDA wiring from GPS module to FC.

---

### Issue: "LD2450 not reporting targets"
**Check:**
1. UART6 wiring correct? (RX on STM32, TX on LD2450)
2. Baud rate 115200? (hardcoded in LD2450)
3. Data format correct? (LD2450 outputs frame-packed data; check reference guide)
4. Power supply: LD2450 needs stable 5V, ~200mA

**Test:** Use a USB-UART adapter on laptop to sniff raw UART bytes from LD2450, verify frames arriving.

---

### Issue: "LD2412 breathing lock never triggers"
**Likely cause:** Distance gate not tuned to your target range, or SNR too low.
**Check:**
1. Is target within 3–5m?
2. Is target *stationary* (even slight motion breaks lock)?
3. Try different distance gate settings (LD2412 has firmware config pins)
4. Verify LD2412 power stable; brownout = lost lock

**Empirical test:** Place target at 0.5m, 1m, 2m, 4m; log breathing_rate field for 10s at each distance. Plot stability vs. range.

---

### Issue: "INMP441 audio stuck at zero"
**Check:**
1. I2S DMA chain set up correctly? (I2S master on STM32, slave on INMP441)
2. I2S clock + data pins wired? (at least 3 pins: BCK, LRCK, DATA)
3. INMP441 power stable (3.3V)?
4. DMA circular buffer size reasonable (e.g., 2048 samples)?

**Test:** Directly read a single I2S sample in debugger; confirm not stuck at 0x0000.

---

### Issue: "Servo PWM not working"
**Check:**
1. TIM2 clock enabled in RCC?
2. GPIO pins PA0/PA1 configured as AF1 (alternate function 1)?
3. TIM2 frequency ~50Hz (20ms period) for servo standard?
4. Pulse width 1.0–2.0ms?

**Test:** Oscilloscope on servo signal; verify 50Hz square wave, duty cycle adjusts.

---

### Issue: "Python sim runs but renders all black"
**Check:**
1. Matplotlib backend: `echo $MPLBACKEND` — should be empty or "TkAgg"
2. Try: `MPLBACKEND=TkAgg python3 sar_sim.py`
3. Or on Windows/WSL: matplotlib should auto-detect WSLg and render to desktop

**Last resort:** Record script output to PNG instead of live window:
```python
# Replace plt.show() with:
ani.save('demo_output.mp4', writer='pillow', fps=10)
```

---

### Issue: "ESP32 UDP packets not reaching laptop"
**Check:**
1. Firewall blocking UDP port? (Windows Defender, Linux iptables)
2. Laptop and ESP32 on same WiFi network?
3. Hardcoded laptop IP in ESP32 sketch correct?
4. Serial monitor on ESP32: any errors on startup?

**Test:**
```bash
# On laptop, listen for UDP on port 5005:
nc -u -l 5005
# (or use a dedicated Python socket listener)
```

---

## LAST-MINUTE DEMO FIXES

If hardware fails 1 hour before demo:

1. **Run pure simulation** (`python3 sar_sim.py` with no real sensor input)
   - Explain: "We're simulating with the identical fusion logic that runs on the real hardware"
   - Judges understand this; SAR robotics labs do this all the time

2. **Pre-record a real demo run** the night before
   - Keep 30–60 second video of system confirming 2–3 survivors
   - Play during demo, narrate the decision chain
   - "Here's a live run from last night; the logic is identical to what's running now"

3. **Focus narrative on the logic, not the hardware**
   - Judges care most about: velocity classification, multi-modal voting, autonomous decisions
   - Physical realization (which sensors, which microcontroller) is secondary

---

## DEMO SCRIPT (3–5 MINUTES)

### Opening (1 min)
> "Project FINDER-Lite is an autonomous triage system for SAR operations. Unlike NASA's ground-penetrating FINDER, we use 24GHz radars for close-range room clearing—think firefighter or HAZMAT team entering a collapsed structure. The innovation isn't the sensors; it's the logic that makes them trustworthy together."

### Live Demo (2–3 min)
[Run `sar_sim.py` or play recorded video]
> "Watch the system autonomously scan the space. [Pause as drone moves.] When it finds someone stationary [velocity filter], it diverts to investigate. [Pause as servos point.] Once close, it stares for 5 seconds, checking breathing, thermal, and acoustic cues [confidence meter fills].
>
> If enough sensors agree—[CONFIRMED SURVIVOR flash]—it locks on. Notice how it rejects the walking person immediately; they're not trapped. The real victim [points to confirmed marker] is stationary *and* breathing *and* occasionally tapping. Multi-modal fusion."

### Closing (1 min)
> "This decision loop—velocity classification, dwell sequencing, sensor voting—is the FINDER innovation. Scaling to true through-rubble range means swapping 24GHz radars for UWB hardware; the autonomy logic stays identical.
>
> We've scoped this project to teach roboticists how SAR sensor fusion actually works, not to claim we've built the full FINDER system. For hackathon purposes, that's an honest and valuable contribution."

### Q&A Answers (Pre-prepared)
**"Why 24GHz, not UWB?"**
→ Cost / availability for a hackathon. UWB is research-grade; 24GHz is hobby-accessible.

**"How do you avoid false positives?"**
→ Multi-modal. Rubble is stationary (✓ velocity check) but doesn't breathe (✗ LD2412 check). We require *both*.

**"Could this work on a drone?"**
→ [Honest:] Vibration breaks breathing detection on LD2412. We'd need vibration isolation or fly it as a data logger (GCS doesn't interpret detections in flight). Ground or pole-mounted is more reliable.

**"What's the real range?"**
→ Breathing lock 2–5m depending on antenna and clutter. We tested empirically in our venue [cite actual number].

---

## POST-HACKATHON ROADMAP

1. **Port C fusion logic to STM32** (replace sim with real embedded decisions)
2. **Add MAVLink telemetry** (tie flight controller attitude to pan/tilt stabilization)
3. **Integrate RCWL-0516** (add lower-frequency confirmation layer)
4. **Test in realistic rubble** (collapsed building mock-up; assess performance)
5. **Upgrade to UWB radar** (true FINDER penetration)
6. **Field trial with SAR teams** (validate with real first-responders)

---

## FINAL MINDSET CHECK

✅ **You have:**
- A real, working fusion state machine (autonomous)
- A professional-looking visualization (impressive)
- A clear, honest pitch (credible)
- A fallback plan if hardware fails (pre-recorded demo)

✅ **You're demonstrating:**
- Understanding of SAR robotics challenges
- Sound multi-modal sensor fusion logic
- Pragmatic engineering (scope, simulation layer)
- Maturity (owning limitations, not overclaiming)

**Judges reward this over flashy, broken hardware. Go build. 🚀**

