"""
Project FINDER-Lite - Python Simulation Layer (Isometric Tactical HUD build)
------------------------------------------------------------------------------
Same autonomous fusion logic as before (SCANNING -> DIVERTING -> STARING ->
CONFIRMED/REJECTED, driven by real velocity classification + synthetic
breathing/acoustic readings). The rendering layer now uses a hand-rolled
isometric projection (no extra 3D libraries needed) to fake a 3D scene:
  - Extruded rubble/obstacle blocks with shaded top + side faces
  - Standing "pin" markers with drop shadows for each human target
  - A hovering drone with a floor shadow + dashed altitude connector line
  - Iso-projected radar range rings + rotating sweep line
  - Pulsing glow ring on confirmed survivors

Run:
    python3 sar_sim.py
Requires: matplotlib, numpy
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from collections import deque
import random

# ----------------------------- CONFIG ------------------------------------

ARENA_W, ARENA_H = 20.0, 14.0
CELL_SIZE = 2.0
SENSOR_RANGE = 6.0
STARE_RANGE = 5.0
DT = 0.15
MOVE_SPEED_DRONE = 1.6
VEL_WINDOW = 14
MOVING_THRESHOLD = 0.35
STARE_DWELL = 5.0
CONFIRM_THRESHOLD = 60

OBST_H = 1.3
TARGET_H = 1.6
DRONE_BASE_Z = 2.8
DRONE_BOB = 0.22

random.seed(7)
np.random.seed(7)

# --- Tactical color palette ---
BG        = "#050b14"
PANEL_BG  = "#0a1522"
FLOOR     = "#0d1c2b"
GRID_LINE = "#16283a"
RING      = "#1c3a52"
SWEEP     = "#22d3ee"
COVERED   = "#0e5a78"
TEXT_MAIN = "#7dd3fc"
TEXT_DIM  = "#3b5568"
MOVING_C    = "#38bdf8"
CANDIDATE_C = "#fbbf24"
CONFIRMED_C = "#ef4444"
REJECTED_C  = "#475569"
OBSTACLE_C  = "#2b3d52"
SHADOW_C    = "#000000"


def shade(hexcol, factor):
    hexcol = hexcol.lstrip("#")
    r, g, b = (int(hexcol[i:i + 2], 16) for i in (0, 2, 4))
    r, g, b = (min(255, max(0, int(c * factor))) for c in (r, g, b))
    return f"#{r:02x}{g:02x}{b:02x}"


# ----------------------------- ISO PROJECTION ------------------------------

ISO_COS = np.cos(np.radians(30))
ISO_SIN = np.sin(np.radians(30))


def iso(x, y, z=0.0):
    sx = (x - y) * ISO_COS
    sy = (x + y) * ISO_SIN - z
    return sx, sy


def iso_circle(cx, cy, r, z=0.0, n=40):
    a = np.linspace(0, 2 * np.pi, n)
    xs, ys = cx + r * np.cos(a), cy + r * np.sin(a)
    pts = np.array([iso(x, y, z) for x, y in zip(xs, ys)])
    return pts


# ----------------------------- ENTITIES -----------------------------------

class Target:
    def __init__(self, tid, kind, pos):
        self.id = tid
        self.kind = kind
        self.pos = np.array(pos, dtype=float)
        self.history = deque(maxlen=VEL_WINDOW)
        self.waypoint = self._new_waypoint() if kind == "bystander" else None
        self.jitter_phase = random.uniform(0, 6.28)
        self.confidence = 0
        self.live_score = 0
        self.last_bpm = 0
        self.last_acoustic = False

    def _new_waypoint(self):
        return np.array([random.uniform(1.5, ARENA_W - 1.5),
                          random.uniform(1.5, ARENA_H - 1.5)])

    def step(self, t):
        self.history.append(self.pos.copy())
        if self.kind == "bystander":
            direction = self.waypoint - self.pos
            dist = np.linalg.norm(direction)
            if dist < 0.3:
                self.waypoint = self._new_waypoint()
            else:
                self.pos += (direction / dist) * 0.9 * DT
        else:
            self.jitter_phase += DT * 0.9
            jitter = 0.04 * np.array([np.sin(self.jitter_phase),
                                       np.cos(self.jitter_phase * 0.7)])
            self.pos += jitter * DT

    def velocity_estimate(self):
        if len(self.history) < 2:
            return 0.0
        disp = np.linalg.norm(self.history[-1] - self.history[0])
        time_span = DT * (len(self.history) - 1)
        return disp / max(time_span, 1e-6)


class Drone:
    def __init__(self):
        self.pos = np.array([1.5, 1.5])
        self.trail = deque(maxlen=50)
        nx = int(np.ceil(ARENA_W / CELL_SIZE))
        ny = int(np.ceil(ARENA_H / CELL_SIZE))
        self.grid_shape = (nx, ny)
        self.visited = np.zeros((nx, ny), dtype=bool)
        self.state = "COVERAGE"
        self.stare_target_id = None
        self.stare_timer = 0.0
        self.resolved = {}
        self.log = deque(maxlen=5)
        self.sweep_angle = 0.0
        self.flash_timer = 0.0
        self.flash_msg = ""
        self.missions_done = 0

    def cell_of(self, pos):
        cx = int(np.clip(pos[0] // CELL_SIZE, 0, self.grid_shape[0] - 1))
        cy = int(np.clip(pos[1] // CELL_SIZE, 0, self.grid_shape[1] - 1))
        return cx, cy

    def mark_visited_near(self):
        cx, cy = self.cell_of(self.pos)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                nx_, ny_ = cx + dx, cy + dy
                if 0 <= nx_ < self.grid_shape[0] and 0 <= ny_ < self.grid_shape[1]:
                    center = np.array([nx_, ny_]) * CELL_SIZE + CELL_SIZE / 2
                    if np.linalg.norm(center - self.pos) <= SENSOR_RANGE:
                        self.visited[nx_, ny_] = True

    def next_unvisited_cell(self):
        unvisited = np.argwhere(~self.visited)
        if len(unvisited) == 0:
            self.visited[:, :] = False
            self.missions_done += 1
            return self.next_unvisited_cell()
        centers = unvisited * CELL_SIZE + CELL_SIZE / 2
        dists = np.linalg.norm(centers - self.pos, axis=1)
        nearest = centers[np.argmin(dists)]
        return nearest

    def move_towards(self, goal):
        direction = goal - self.pos
        dist = np.linalg.norm(direction)
        if dist > 1e-6:
            step = min(MOVE_SPEED_DRONE * DT, dist)
            self.pos += (direction / dist) * step
        self.trail.append(self.pos.copy())


# ----------------------------- FUSION LOGIC --------------------------------

def classify_motion(target):
    v = target.velocity_estimate()
    return "MOVING" if v > MOVING_THRESHOLD else "QUASI_STATIC"


def synth_breathing_rate(target, t):
    if target.kind == "victim":
        bpm = 16 + 1.2 * np.sin(t * 0.6) + np.random.normal(0, 0.4)
        return max(bpm, 0), True
    bpm = np.random.choice([0, 0, 0, np.random.uniform(35, 70)])
    return bpm, False


def synth_acoustic_event(target, t):
    if target.kind == "victim":
        return (int(t * 2) % 9 == 0)
    return random.random() < 0.02


def fusion_step(drone, targets, t):
    drone.mark_visited_near()
    if drone.flash_timer > 0:
        drone.flash_timer -= DT

    candidates = [
        tg for tg in targets
        if tg.id not in drone.resolved
        and classify_motion(tg) == "QUASI_STATIC"
        and np.linalg.norm(tg.pos - drone.pos) <= STARE_RANGE
    ]

    if drone.state == "COVERAGE":
        if candidates:
            candidates.sort(key=lambda tg: np.linalg.norm(tg.pos - drone.pos))
            drone.stare_target_id = candidates[0].id
            drone.state = "DIVERTING"
            drone.log.append(f"[{t:5.1f}s] Candidate T{drone.stare_target_id} -> diverting")
        else:
            goal = drone.next_unvisited_cell()
            drone.move_towards(goal)

    elif drone.state == "DIVERTING":
        target = next(tg for tg in targets if tg.id == drone.stare_target_id)
        drone.move_towards(target.pos)
        if np.linalg.norm(target.pos - drone.pos) < 0.6:
            drone.state = "STARING"
            drone.stare_timer = 0.0
            drone.log.append(f"[{t:5.1f}s] Staring on T{drone.stare_target_id}")

    elif drone.state == "STARING":
        drone.stare_timer += DT
        target = next(tg for tg in targets if tg.id == drone.stare_target_id)

        bpm, clean_lock = synth_breathing_rate(target, t)
        acoustic_hit = synth_acoustic_event(target, t)
        target.last_bpm = bpm
        target.last_acoustic = acoustic_hit

        live = 0
        if clean_lock and 8 <= bpm <= 30:
            live += 40
        if classify_motion(target) == "QUASI_STATIC":
            live += 30
        if acoustic_hit:
            live += 20
        live += 10 * (drone.stare_timer / STARE_DWELL)
        target.live_score = live

        if drone.stare_timer >= STARE_DWELL:
            score = 0
            if clean_lock and 8 <= bpm <= 30:
                score += 40
            if classify_motion(target) == "QUASI_STATIC":
                score += 30
            if acoustic_hit:
                score += 20
            score += 10
            target.confidence = score
            target.live_score = score

            if score >= CONFIRM_THRESHOLD:
                drone.resolved[target.id] = "CONFIRMED"
                drone.log.append(f"[{t:5.1f}s] *** CONFIRMED T{target.id} (score {score}) ***")
                drone.flash_timer = 2.5
                drone.flash_msg = f"SURVIVOR CONFIRMED — TARGET T{target.id}"
            else:
                drone.resolved[target.id] = "REJECTED"
                drone.log.append(f"[{t:5.1f}s] Cleared T{target.id} (score {score})")

            drone.state = "COVERAGE"
            drone.stare_target_id = None


# ----------------------------- WORLD SETUP ---------------------------------

targets = [
    Target(0, "bystander", (4, 3)),
    Target(1, "bystander", (14, 10)),
    Target(2, "bystander", (8, 8)),
    Target(3, "victim", (16, 4)),
]
drone = Drone()
sim_t = 0.0

OBSTACLES = [
    (6.5, 5.5, 2.2, 1.2), (11.0, 2.0, 1.5, 3.0), (3.0, 9.5, 2.5, 1.0),
    (15.5, 8.0, 1.8, 2.5), (9.0, 11.5, 3.0, 1.0),
]

# ----------------------------- VISUALIZATION -------------------------------

plt.rcParams["text.color"] = TEXT_MAIN
fig, (ax_map, ax_panel) = plt.subplots(
    1, 2, figsize=(14.5, 6.8), gridspec_kw={"width_ratios": [2.15, 1]}
)
fig.patch.set_facecolor(BG)
fig.suptitle("PROJECT FINDER-LITE  //  AUTONOMOUS SAR TRIAGE — LIVE FEED",
             fontsize=13, color=SWEEP, family="monospace", fontweight="bold")

ax_map.set_facecolor(BG)
ax_map.set_xticks([]); ax_map.set_yticks([])
for spine in ax_map.spines.values():
    spine.set_visible(False)
ax_map.set_aspect("equal")

# --- compute iso bounding box for axis limits ---
corners = [(0, 0), (ARENA_W, 0), (ARENA_W, ARENA_H), (0, ARENA_H)]
all_pts = [iso(x, y, z) for x, y in corners for z in (0, DRONE_BASE_Z + DRONE_BOB + 1.0)]
all_pts = np.array(all_pts)
mx, Mx = all_pts[:, 0].min(), all_pts[:, 0].max()
my, My = all_pts[:, 1].min(), all_pts[:, 1].max()
pad = 1.5
ax_map.set_xlim(mx - pad, Mx + pad)
ax_map.set_ylim(my - pad, My + pad)

# --- floor plane ---
floor_poly = Polygon([iso(x, y, 0) for x, y in corners], closed=True,
                      facecolor=FLOOR, edgecolor=GRID_LINE, linewidth=1.2, zorder=0)
ax_map.add_patch(floor_poly)

for gx in np.arange(0, ARENA_W + 0.01, CELL_SIZE):
    p1, p2 = iso(gx, 0, 0), iso(gx, ARENA_H, 0)
    ax_map.plot([p1[0], p2[0]], [p1[1], p2[1]], color=GRID_LINE, linewidth=0.6, zorder=0.2)
for gy in np.arange(0, ARENA_H + 0.01, CELL_SIZE):
    p1, p2 = iso(0, gy, 0), iso(ARENA_W, gy, 0)
    ax_map.plot([p1[0], p2[0]], [p1[1], p2[1]], color=GRID_LINE, linewidth=0.6, zorder=0.2)

# --- coverage cells (precomputed static polygons, alpha toggled per frame) ---
drone_tmp = drone
coverage_patches = {}
for i in range(drone.grid_shape[0]):
    for j in range(drone.grid_shape[1]):
        cx0, cy0 = i * CELL_SIZE, j * CELL_SIZE
        verts = [iso(cx0, cy0, 0.01), iso(cx0 + CELL_SIZE, cy0, 0.01),
                 iso(cx0 + CELL_SIZE, cy0 + CELL_SIZE, 0.01), iso(cx0, cy0 + CELL_SIZE, 0.01)]
        poly = Polygon(verts, closed=True, facecolor=COVERED, edgecolor="none",
                        alpha=0.0, zorder=0.5)
        ax_map.add_patch(poly)
        coverage_patches[(i, j)] = poly

# --- obstacles: extruded boxes (top + two shaded side faces), static ---
for (ox, oy, ow, oh) in OBSTACLES:
    P1, P2, P3, P4 = (ox, oy), (ox + ow, oy), (ox + ow, oy + oh), (ox, oy + oh)
    top = [iso(*P1, OBST_H), iso(*P2, OBST_H), iso(*P3, OBST_H), iso(*P4, OBST_H)]
    side_a = [iso(*P1, 0), iso(*P2, 0), iso(*P2, OBST_H), iso(*P1, OBST_H)]
    side_b = [iso(*P2, 0), iso(*P3, 0), iso(*P3, OBST_H), iso(*P2, OBST_H)]
    depth_key = (ox + oy + ow / 2 + oh / 2)
    z_base = 2 + depth_key * 0.01
    ax_map.add_patch(Polygon(side_b, closed=True, facecolor=shade(OBSTACLE_C, 0.55),
                              edgecolor=BG, linewidth=0.5, zorder=z_base))
    ax_map.add_patch(Polygon(side_a, closed=True, facecolor=shade(OBSTACLE_C, 0.8),
                              edgecolor=BG, linewidth=0.5, zorder=z_base + 0.01))
    ax_map.add_patch(Polygon(top, closed=True, facecolor=shade(OBSTACLE_C, 1.25),
                              edgecolor=BG, linewidth=0.5, zorder=z_base + 0.02))

# --- dynamic: range rings + sweep ---
range_ring_lines = []
for r in (2, 4, 6):
    line, = ax_map.plot([], [], color=RING, linewidth=1, linestyle="--", alpha=0.8, zorder=1)
    range_ring_lines.append((r, line))
sweep_line, = ax_map.plot([], [], color=SWEEP, linewidth=1.6, alpha=0.85, zorder=1.1)

# --- dynamic: drone (shadow, connector, body) ---
drone_shadow = Polygon(iso_circle(1.5, 1.5, 0.55, 0.02), closed=True,
                        facecolor=SHADOW_C, alpha=0.45, zorder=1.2)
ax_map.add_patch(drone_shadow)
drone_connector, = ax_map.plot([], [], color="#94a3b8", linewidth=1, linestyle=(0, (3, 2)), zorder=1.3)
drone_trail_line, = ax_map.plot([], [], color=SWEEP, alpha=0.3, linewidth=1.2, zorder=1.3)
drone_body, = ax_map.plot([], [], marker="D", markersize=13, color="white",
                           markeredgecolor=SWEEP, markeredgewidth=1.6, zorder=50)

# --- dynamic: targets (shadow, pole, head, glow, label, trail) ---
COLORS = {"MOVING": MOVING_C, "QUASI_STATIC": CANDIDATE_C,
          "CONFIRMED": CONFIRMED_C, "REJECTED": REJECTED_C}

t_shadow, t_pole, t_head, t_glow, t_label, t_trail = {}, {}, {}, {}, {}, {}
for tg in targets:
    t_shadow[tg.id] = Polygon(iso_circle(*tg.pos, 0.32, 0.01), closed=True,
                               facecolor=SHADOW_C, alpha=0.4, zorder=2)
    ax_map.add_patch(t_shadow[tg.id])
    line, = ax_map.plot([], [], color="white", linewidth=2, zorder=2.1)
    t_pole[tg.id] = line
    head, = ax_map.plot([], [], marker="o", markersize=10, zorder=2.2,
                        markeredgecolor="white", markeredgewidth=0.6)
    t_head[tg.id] = head
    glow, = ax_map.plot([], [], color=CONFIRMED_C, linewidth=2, alpha=0.0, zorder=2.15)
    t_glow[tg.id] = glow
    trail, = ax_map.plot([], [], alpha=0.28, linewidth=1, zorder=1.9)
    t_trail[tg.id] = trail
    t_label[tg.id] = ax_map.text(0, 0, "", fontsize=8, color=TEXT_MAIN,
                                  family="monospace", zorder=2.3)

flash_text = ax_map.text(0, My - 0.6, "", ha="center", va="center", fontsize=13,
                          color=CONFIRMED_C, family="monospace", fontweight="bold", zorder=60)

# --- side panel ---
ax_panel.set_facecolor(PANEL_BG)
ax_panel.set_xlim(0, 1); ax_panel.set_ylim(0, 1)
ax_panel.axis("off")

panel_text = ax_panel.text(0.04, 0.97, "", va="top", ha="left", family="monospace",
                            fontsize=8.8, color=TEXT_MAIN, transform=ax_panel.transAxes,
                            linespacing=1.45)

meter_bg = Polygon([(0.04, 0.145), (0.96, 0.145), (0.96, 0.195), (0.04, 0.195)],
                    closed=True, facecolor="#0f2233", edgecolor=RING, transform=ax_panel.transAxes, zorder=2)
meter_fill = Polygon([(0.04, 0.145), (0.04, 0.145), (0.04, 0.195), (0.04, 0.195)],
                      closed=True, facecolor=CANDIDATE_C, transform=ax_panel.transAxes, zorder=3)
ax_panel.add_patch(meter_bg)
ax_panel.add_patch(meter_fill)
ax_panel.text(0.04, 0.125, "CONFIDENCE", family="monospace", fontsize=8,
              color=TEXT_DIM, transform=ax_panel.transAxes)

legend_items = [("MOVING (bystander)", MOVING_C), ("CANDIDATE (quasi-static)", CANDIDATE_C),
                ("CONFIRMED SURVIVOR", CONFIRMED_C), ("REJECTED", REJECTED_C)]
for k, (lbl, col) in enumerate(legend_items):
    y = 0.085 - k * 0.028
    ax_panel.plot([0.05], [y], marker="o", markersize=7, color=col,
                  transform=ax_panel.transAxes, clip_on=False)
    ax_panel.text(0.09, y, lbl, family="monospace", fontsize=7.6, color="#6b8caa",
                  va="center", transform=ax_panel.transAxes)


def update(frame):
    global sim_t
    sim_t += DT

    for tg in targets:
        tg.step(sim_t)
    fusion_step(drone, targets, sim_t)

    dz = DRONE_BASE_Z + DRONE_BOB * np.sin(sim_t * 2.2)
    body_xy = iso(drone.pos[0], drone.pos[1], dz)
    shadow_xy = iso(drone.pos[0], drone.pos[1], 0.02)
    drone_body.set_data([body_xy[0]], [body_xy[1]])
    drone_shadow.set_xy(iso_circle(drone.pos[0], drone.pos[1], 0.55, 0.02))
    drone_connector.set_data([body_xy[0], shadow_xy[0]], [body_xy[1], shadow_xy[1]])

    if drone.trail:
        tr = np.array([iso(p[0], p[1], 0.03) for p in drone.trail])
        drone_trail_line.set_data(tr[:, 0], tr[:, 1])

    for r, line in range_ring_lines:
        pts = iso_circle(drone.pos[0], drone.pos[1], r, 0.02)
        line.set_data(pts[:, 0], pts[:, 1])

    drone.sweep_angle += 0.12
    ex = drone.pos[0] + SENSOR_RANGE * np.cos(drone.sweep_angle)
    ey = drone.pos[1] + SENSOR_RANGE * np.sin(drone.sweep_angle)
    p1, p2 = iso(drone.pos[0], drone.pos[1], 0.02), iso(ex, ey, 0.02)
    sweep_line.set_data([p1[0], p2[0]], [p1[1], p2[1]])

    for (i, j), poly in coverage_patches.items():
        poly.set_alpha(0.35 if drone.visited[i, j] else 0.0)

    for tg in targets:
        status = drone.resolved.get(tg.id)
        motion = classify_motion(tg)
        color = COLORS[status] if status else COLORS[motion]

        x, y = tg.pos
        base = iso(x, y, 0.01)
        top = iso(x, y, TARGET_H)
        t_shadow[tg.id].set_xy(iso_circle(x, y, 0.32, 0.01))
        t_pole[tg.id].set_data([base[0], top[0]], [base[1], top[1]])
        t_pole[tg.id].set_color(color)
        t_head[tg.id].set_data([top[0]], [top[1]])
        t_head[tg.id].set_color(color)

        if tg.history:
            hist = np.array([iso(p[0], p[1], 0.02) for p in tg.history])
            t_trail[tg.id].set_data(hist[:, 0], hist[:, 1])
            t_trail[tg.id].set_color(color)

        if status == "CONFIRMED":
            pulse_r = 0.5 + 0.22 * (0.5 + 0.5 * np.sin(sim_t * 4))
            ring_pts = iso_circle(x, y, pulse_r, 0.02)
            t_glow[tg.id].set_data(ring_pts[:, 0], ring_pts[:, 1])
            t_glow[tg.id].set_alpha(0.7)
        else:
            t_glow[tg.id].set_alpha(0.0)

        label = f"T{tg.id}" + (" \u2605" if status == "CONFIRMED" else "")
        t_label[tg.id].set_position((top[0] + 0.25, top[1] + 0.25))
        t_label[tg.id].set_text(label)
        t_label[tg.id].set_color(color)

    if drone.flash_timer > 0:
        alpha = min(drone.flash_timer / 2.5, 1.0)
        flash_text.set_position(( (mx+Mx)/2, My - 0.3))
        flash_text.set_text(drone.flash_msg)
        flash_text.set_alpha(alpha)
    else:
        flash_text.set_text("")

    lines = []
    lines.append(f" TIME {sim_t:6.1f}s   STATE: {drone.state}")
    lines.append(f" SWEEPS COMPLETE: {drone.missions_done}")
    lines.append("-" * 30)
    if drone.stare_target_id is not None:
        tg = next(t for t in targets if t.id == drone.stare_target_id)
        lines.append(f" ACTIVE TARGET   : T{tg.id}")
        lines.append(f"   breathing     : {tg.last_bpm:5.1f} BPM")
        lines.append(f"   acoustic      : {'HIT' if tg.last_acoustic else '---'}")
        lines.append(f"   dwell         : {drone.stare_timer:4.1f}/{STARE_DWELL:.1f}s")
        live = tg.live_score
    else:
        lines.append(" ACTIVE TARGET   : none (scanning)")
        live = 0
    lines.append("-" * 30)
    lines.append(f" CONFIRMED: {sum(1 for v in drone.resolved.values() if v=='CONFIRMED')}  "
                 f"REJECTED: {sum(1 for v in drone.resolved.values() if v=='REJECTED')}")
    lines.append("-" * 30)
    lines.append(" EVENT LOG:")
    for entry in drone.log:
        lines.append(" " + entry)
    panel_text.set_text("\n".join(lines))

    frac = 0.92 * min(live, 100) / 100
    x0 = 0.04
    meter_fill.set_xy([(x0, 0.145), (x0 + frac, 0.145), (x0 + frac, 0.195), (x0, 0.195)])
    meter_fill.set_facecolor(CONFIRMED_C if live >= CONFIRM_THRESHOLD else CANDIDATE_C)

    return [drone_body, drone_shadow, drone_connector, sweep_line, panel_text,
            meter_fill, flash_text] + list(t_head.values())


ani = animation.FuncAnimation(fig, update, interval=int(DT * 1000), blit=False,
                               cache_frame_data=False)
plt.tight_layout()
plt.show()
